package com.example.vremetowidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            setBackgroundColor(android.graphics.Color.rgb(11, 18, 32))
        }
        val title = TextView(this).apply {
            text = "Времето оттогава"
            textSize = 26f
            setTextColor(android.graphics.Color.WHITE)
        }
        val info = TextView(this).apply {
            text = "\nДобави Widget към началния екран, за да виждаш трите брояча.\n\nАко бутонът не се поддържа от стартера, натисни продължително върху празно място на началния екран → Widgets → Времето оттогава."
            textSize = 16f
            setTextColor(android.graphics.Color.LTGRAY)
        }
        val button = Button(this).apply {
            text = "Добави Widget"
            setOnClickListener {
                val manager = AppWidgetManager.getInstance(this@MainActivity)
                val provider = ComponentName(this@MainActivity, TimeWidgetProvider::class.java)
                if (android.os.Build.VERSION.SDK_INT >= 26 && manager.isRequestPinAppWidgetSupported) {
                    manager.requestPinAppWidget(provider, null, null)
                } else {
                    info.text = "Отвори менюто Widgets на началния екран и избери „Времето оттогава“."
                }
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(button)
        setContentView(layout)
    }
}
