package com.example.vremetowidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import android.os.SystemClock
import java.text.NumberFormat
import java.time.Duration
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit
import java.util.Locale

class TimeWidgetProvider : AppWidgetProvider() {
    private data class Counter(val title: String, val start: LocalDateTime, val calendarId: Int, val chronoId: Int, val statsId: Int)

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    companion object {
        private val counters = listOf(
            Counter("Началото", LocalDateTime.of(2026, 9, 8, 18, 0), R.id.calendar1, R.id.chrono1, R.id.stats1),
            Counter("Забраната", LocalDateTime.of(2026, 11, 5, 18, 0), R.id.calendar2, R.id.chrono2, R.id.stats2),
            Counter("Официален край", LocalDateTime.of(2026, 11, 20, 18, 0), R.id.calendar3, R.id.chrono3, R.id.stats3)
        )
        private fun number(value: Long): String = NumberFormat.getIntegerInstance(Locale("bg", "BG")).format(value)

        fun updateOne(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_time)
            val now = LocalDateTime.now()
            val nowMillis = System.currentTimeMillis()
            val elapsedRealtime = SystemClock.elapsedRealtime()

            counters.forEach { c ->
                val seconds = ChronoUnit.SECONDS.between(c.start, now).coerceAtLeast(0)
                val future = now.isBefore(c.start)
                val months = if (future) 0L else ChronoUnit.MONTHS.between(c.start, now)
                val anchor = c.start.plusMonths(months)
                val days = if (future) 0L else ChronoUnit.DAYS.between(anchor, now)
                val calendarText = if (future) "Все още не е започнало"
                    else "$months ${if (months == 1L) "месец" else "месеца"} и $days ${if (days == 1L) "ден" else "дни"}"
                views.setTextViewText(c.calendarId, calendarText)

                val startMillis = c.start.atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
                val elapsedMs = (nowMillis - startMillis).coerceAtLeast(0L)
                val base = elapsedRealtime - elapsedMs
                views.setChronometer(c.chronoId, base, "%s", !future)

                val weeks = seconds / 604800
                val totalDays = seconds / 86400
                val hours = seconds / 3600
                val minutes = seconds / 60
                val stats = "Седмици ${number(weeks)} · Дни ${number(totalDays)} · Часове ${number(hours)}\nМинути ${number(minutes)} · Секунди ${number(seconds)}"
                views.setTextViewText(c.statsId, stats)
            }
            val time = java.time.LocalTime.now().withNano(0).toString()
            views.setTextViewText(R.id.updated, "Последно обновяване: $time")
            val intent = android.content.Intent(context, TimeWidgetProvider::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, intArrayOf(widgetId))
            }
            val pending = android.app.PendingIntent.getBroadcast(
                context, widgetId, intent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.updated, pending)
            manager.updateAppWidget(widgetId, views)
        }
    }
}
